<template>
  <div>
    <Home />
  </div>
</template>

<script>
import Home from "@storefront-ui/vue/src/components/pages/home/Home"
export default {
  components: {
    Home
  }
}
</script>
