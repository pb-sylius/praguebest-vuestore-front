<template>
  <Product />
</template>

<script>
import Product from "@storefront-ui/vue/src/components/pages/product/Product";
export default {
  components: {
    Product
  }
};
</script>
