export default {
  viewBox: "0 0 24 24",
  paths: [
    "M2 8.364L3.6 7l8.4 7.254L20.4 7 22 8.364 12 17z"
  ]
};