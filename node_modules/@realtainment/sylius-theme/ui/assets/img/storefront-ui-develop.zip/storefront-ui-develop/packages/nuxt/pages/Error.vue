<template>
  <Error />
</template>

<script>
import Error from "@storefront-ui/vue/src/components/pages/error/Error";

export default {
  components: {
    Error
  }
};
</script>
