<template>
  <MyAccount />
</template>

<script>
import MyAccount from "@storefront-ui/vue/src/components/pages/my-account/MyAccount";

export default {
  components: {
    MyAccount
  }
};
</script>
