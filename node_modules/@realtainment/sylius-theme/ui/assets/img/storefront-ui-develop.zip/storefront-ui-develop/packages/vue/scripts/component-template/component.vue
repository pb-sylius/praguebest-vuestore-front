<template>
  <div class="ComponentNameKebabCase"></div>
</template>
<script>
export default {
  name: "ComponentNameCamelCase"
};
</script>
<style lang="scss">
@import "~@storefront-ui/shared/styles/components/ComponentFolder/ComponentNameCamelCase.scss";
</style>
