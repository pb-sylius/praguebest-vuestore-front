# [[component-name]]

[[component-description]]

[[toc]]

## Most common usage scenario

[[storybook-iframe]]

[[storybook-code]]

## Props

[[props]]

## Slots

[[slots]]

## Events

[[events]]

## CSS modifiers

[[css-modifiers]]

## CSS custom properties (variables)

[[css-variables]]

You can override CSS variables values bound to this component.

<!-- No _internal components -->

## Play with this component

See all available configurations and play with this component on <a href="https://storybook.storefrontui.io/?path=/story/[[storybook-link]]">Storybook</a>.
