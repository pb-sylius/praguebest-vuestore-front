<template>
  <Static />
</template>

<script>
import Static from "@storefront-ui/vue/src/components/pages/static/Static";

export default {
  components: {
    Static
  }
};
</script>
