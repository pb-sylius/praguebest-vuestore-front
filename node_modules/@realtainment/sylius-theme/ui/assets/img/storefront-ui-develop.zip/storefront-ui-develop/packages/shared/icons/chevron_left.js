export default {
  viewBox: "0 0 24 24",
  paths: [
    "M15.636 2L17 3.6 9.746 12 17 20.4 15.636 22 7 12z"
  ]
};