export default {
  viewBox: "0 0 24 24",
  paths: [
    "M22 15.636L20.4 17 12 9.746 3.6 17 2 15.636 12 7z"
  ]
};