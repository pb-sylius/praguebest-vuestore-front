export default {
  viewBox: "0 0 24 24",
  paths: [
    "M2 3h20v3.636H2zM2 17.545h20v3.636H2zM2 10.273h12.727v3.636H2z"
  ]
};