import { SfRadio } from "@storefront-ui/vue";
export default {
  title: "Components/Molecules/Radio",
  component: SfRadio,
  parameters: {
    // do not modify cssprops manually, they are generated automatically by update-components-docs script
    cssprops: {},
    // end of code generated automatically
    docs: {
      description: {
        component: "Radio button component with label and description.",
      },
    },
  },
  argTypes: {
    classes: {
      control: {
        type: "select",
        options: ["sf-radio--transparent", ""],
      },
      table: {
        category: "CSS Modifiers",
      },
      description: "CSS classes to modify component styling",
    },
    selected: {
      control: "text",
      table: {
        category: "Props",
        type: {
          summary: "string",
        },
        defaultValue: {
          summary: "",
        },
      },
      defaultValue: "",
      description: "Value of the selected option",
    },
    name: {
      control: "text",
      table: {
        category: "Props",
      },
      defaultValue: "",
      description: "Name of the option",
    },
    value: {
      control: "text",
      table: {
        category: "Props",
      },
      defaultValue: "",
      description: "Value of the option",
    },
    label: {
      control: "text",
      table: {
        category: "Props",
        type: {
          summary: "string",
        },
        defaultValue: {
          summary: "",
        },
      },
      defaultValue: "",
      description: "Label for option",
    },
    details: {
      control: "text",
      table: {
        category: "Props",
        type: {
          summary: "string",
        },
        defaultValue: {
          summary: "",
        },
      },
      type: {
        summary: "string",
      },
      defaultValue: "",
      description: "Option details",
    },
    description: {
      control: "text",
      table: {
        category: "Props",
        type: {
          summary: "string",
        },
        defaultValue: {
          summary: "",
        },
      },
      defaultValue: "",
      description: "Additional description to the radio option to display",
    },
    disabled: {
      control: "boolean",
      table: {
        category: "Props",
        defaultValue: {
          summary: false,
        },
      },
      defaultValue: "",
      description: "Indicate if this option is disabled",
    },
    "v-model": {
      control: "text",
      table: {
        type: {
          summary: "text",
        },
        category: "v-model",
        defaultValue: {
          summary: "",
        },
      },
      defaultValue: "",
      description: "v-model accepts `selected` prop and emits `change` event",
    },
    change: {
      action: "change event emitted",
      table: { category: "Events" },
      description: "Emits change event when option is clicked",
    },
    input: {
      action: "input event emitted",
      table: { category: "Events" },
      description: "Emits input event when option is clicked",
    },
    checkmark: {
      table: {
        category: "Slots",
        type: {
          summary: null,
        },
      },
      description: "Custom checkmark markup",
    },
    "label ": {
      table: {
        category: "Slots",
        type: {
          summary: null,
        },
      },
      description: "Use this slot to have custom label",
    },
    "details ": {
      table: {
        category: "Slots",
        type: {
          summary: null,
        },
      },
      description: "Use this slot to have custom details",
    },
    "description ": {
      table: {
        category: "Slots",
        type: {
          summary: null,
        },
      },
      description: "Use this slot to have custom description",
    },
  },
};

const Template = (args, { argTypes }) => ({
  components: { SfRadio },
  props: Object.keys(argTypes),
  data() {
    return {
      selectedValue: "",
    };
  },
  template: `
  <SfRadio
    :class="classes"
    :label="label"
    :details="details"
    :description="description"
    :name="name"
    :value="value"
    :disabled="disabled"
    v-model="selectedValue"
    @change="change"
    @input="input"
  />`,
});

export const Common = Template.bind({});
Common.args = {
  label: "Pickup in the store",
  details: "Delivery from 4-6 business days",
  description:
    "Novelty! From now on you have the option of picking up an order in the selected InPack parceler. Just remember that in the case of orders paid on delivery, only the card payment will be accepted.",
  name: "Shipping",
  value: "store",
  disabled: false,
};

export const TransparentSelected = Template.bind({});
TransparentSelected.args = {
  ...Common.args,
  classes: "sf-radio--transparent",
};

export const Disabled = Template.bind({});
Disabled.args = {
  ...Common.args,
  disabled: true,
};

export const UseCheckmarkSlot = (args, { argTypes }) => ({
  components: { SfRadio },
  props: Object.keys(argTypes),
  template: `
  <SfRadio
    :class="classes"
    :label="label"
    :details="details"
    :description="description"
    :name="name"
    :value="value"
    :disabled="disabled"
    @change="change"
    @input="input"
  >
    <template #checkmark="{isChecked, disabled}">
      <div v-if="isChecked">😀</div>
      <div v-else>😔</div>
    </template>
  </SfRadio>`,
});
UseCheckmarkSlot.args = { ...Common.args };

export const UseLabelSlot = (args, { argTypes }) => ({
  components: { SfRadio },
  props: Object.keys(argTypes),
  template: `
  <SfRadio
    :class="classes"
    :label="label"
    :details="details"
    :description="description"
    :name="name"
    :value="value"
    :disabled="disabled"
    @change="change"
    @input="input"
  >
    <template #label="{label, isChecked, disabled}">
      CUSTOM LABEL
    </template>
  </SfRadio>`,
});
UseLabelSlot.args = { ...Common.args };

export const UseDetailsSlot = (args, { argTypes }) => ({
  components: { SfRadio },
  props: Object.keys(argTypes),
  template: `
  <SfRadio
    :class="classes"
    :label="label"
    :details="details"
    :description="description"
    :name="name"
    :value="value"
    :disabled="disabled"
    @change="change"
    @input="input"
  >
    <template #details="{details}">
      CUSTOM DETAILS
    </template>
  </SfRadio>`,
});
UseDetailsSlot.args = { ...Common.args };

export const UseDescriptionSlot = (args, { argTypes }) => ({
  components: { SfRadio },
  props: Object.keys(argTypes),
  template: `
  <SfRadio
    :class="classes"
    :label="label"
    :details="details"
    :description="description"
    :name="name"
    :value="value"
    :disabled="disabled"
    @change="change"
    @input="input"
  >
    <template #description="{description}">
      CUSTOM DESCRIPTION
    </template>
  </SfRadio>`,
});
UseDescriptionSlot.args = { ...Common.args };
