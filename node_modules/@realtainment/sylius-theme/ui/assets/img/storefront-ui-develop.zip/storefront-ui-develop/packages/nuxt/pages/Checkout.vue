<template>
  <Checkout />
</template>
<script>
import Checkout from "@storefront-ui/vue/src/components/pages/checkout/Checkout";

export default {
  components: {
    Checkout
  }
};
</script>
