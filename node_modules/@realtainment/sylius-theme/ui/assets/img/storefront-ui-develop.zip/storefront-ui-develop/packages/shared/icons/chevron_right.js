export default {
  viewBox: "0 0 24 24",
  paths: [
    "M8.364 22L7 20.4l7.254-8.4L7 3.6 8.364 2 17 12z"
  ]
};