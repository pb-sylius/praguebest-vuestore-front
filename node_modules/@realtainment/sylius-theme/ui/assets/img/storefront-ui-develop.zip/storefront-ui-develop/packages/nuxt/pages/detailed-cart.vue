<template>
  <div>
    <DetailedCart />
  </div>
</template>

<script>
  import DetailedCart from "@storefront-ui/vue/src/components/pages/detailed-cart/DetailedCart"
  export default {
    components: {
      DetailedCart
    }
  }
</script>
