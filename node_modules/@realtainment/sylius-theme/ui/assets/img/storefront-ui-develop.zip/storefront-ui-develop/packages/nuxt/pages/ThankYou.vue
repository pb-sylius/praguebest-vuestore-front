<template>
  <ThankYou />
</template>

<script>
import ThankYou from "@storefront-ui/vue/src/components/pages/thank-you/ThankYou.vue";

export default {
  components: {
    ThankYou
  }
};
</script>
