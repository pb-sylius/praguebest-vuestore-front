<template>
  <Category />
</template>

<script>
import Category from "@storefront-ui/vue/src/components/pages/category/Category";

export default {
  components: {
    Category
  }
};
</script>


